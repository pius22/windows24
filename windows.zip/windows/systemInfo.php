<?php
//FINDING WINDOWS CLASSIFIED DETAILS
$Ram = shell_exec('systeminfo | find "Total Physical Memory"');
$biosV = shell_exec('systeminfo | find "BIOS Version"');
$DeviceModel = shell_exec('systeminfo | find "System Model"');
$DeviceUser = shell_exec('systeminfo | find "Host Name"');
$DeviceMan = shell_exec('systeminfo | find "System Manufacturer"');
$DeviceTZone = shell_exec('systeminfo | find "Time Zone"');
$user = shell_exec('whoami');
echo $Ram;
//=============================
// TO BE CONTINUED...
//=============================